package com.amu.mainaction;

/**
 *
 * @author Amulya
 */
public interface AMUConstant {
    
    public int PATIENT_ASSIGN = 0;
    public int PATIENT_ACCCPT = 1;
    public int PATIENT_REJECT = 2;
    
}
